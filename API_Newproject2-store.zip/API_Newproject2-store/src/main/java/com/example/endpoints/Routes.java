package com.example.endpoints;

public class Routes {

	public static String baseuri="https://petstore.swagger.io/v2";
	public static String post_basePath="/store";
	public static String get_basePath="/store/{id}";
	public static String delete_basePath="/store/{id}";
	public static String update_basePath="/store/{id}";
	
}