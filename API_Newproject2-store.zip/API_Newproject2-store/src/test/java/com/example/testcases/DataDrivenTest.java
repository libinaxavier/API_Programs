package com.example.testcases;

import org.junit.Assert;
import org.testng.annotations.Test;

import com.example.endpoints.UserEndPoints;
import com.example.payload.UserModel;
import com.example.utilities.DataProviders;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DataDrivenTest {
	@Test(priority=1,dataProvider="data",dataProviderClass=DataProviders.class)
	public void testPostUser(String id,String petId,String quantity,String shipDate,String status,String complete) {
		RestAssured.useRelaxedHTTPSValidation();
		UserModel user=new UserModel();
		user.setId(Integer.parseInt(id));
		user.setPetId(Integer.parseInt(petId));
		user.setQuantity(Integer.parseInt(quantity));
		user.setShipDate(shipDate);
		user.setStatus(status);
		user.setComplete(complete);
		Response response=UserEndPoints.createUser(user);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),201);
	}
	@Test(priority=2,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	public void testGetUserByName(String id)
    {
        Response response = UserEndPoints.getUser(id);
       response.then().log().all();
       Assert.assertEquals(response.getStatusCode(),200);
    }
	@Test(priority=3,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	public void testUpdateByUserName(String id) {
	UserModel payload=new UserModel();
	RestAssured.useRelaxedHTTPSValidation();
	Response response=UserEndPoints.updateUser(id,payload);
	response.then().log().all();
	Assert.assertEquals(response.getStatusCode(),200);
	}
	@Test(priority=4,dataProvider="UserNames",dataProviderClass=DataProviders.class)
	public void testDeleteByUserName(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		
		Response response=UserEndPoints.deleteUser(id);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(),200);
	}
}
