package endpoints;

public class Routes {
	public static String baseuri="https://gorest.co.in/public/v2/";
	public static String post_basePath="/users";
	public static String get_basePath="/users/{id}";
	public static String delete_basePath="/users/{id}";
	public static String update_basePath="/users/{id}";
}
